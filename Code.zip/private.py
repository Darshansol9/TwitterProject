'''
All Twitter information for hitting an api, and fetching their data is written here
'''
CONSUMER_KEY = 'Consumer_Key'
CONSUMER_SECRET ='Secret Consumer Key'
ACCESS_KEY = 'Access Key For Twitter App'
ACCESS_SECRET = 'Access Secret Token'
